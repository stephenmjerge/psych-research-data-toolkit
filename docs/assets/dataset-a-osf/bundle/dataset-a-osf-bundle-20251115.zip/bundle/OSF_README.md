# PRDT Dataset A Bundle (Demo)

- Generated: 2025-11-15 with `scripts/run_dataset_a_osf_demo.sh`
- Input: data/examples/dataset_a_demo.csv
- Manifest: run_manifest_20251115T021847Z.json

## Contents
- interim_clean.csv — anonymized Dataset A demo
- report.json / alerts.json / data_dictionary.csv
- hist_* / missingness / trend / scale plots (PNG)
- See `../provenance/` for run manifest + config snapshot
